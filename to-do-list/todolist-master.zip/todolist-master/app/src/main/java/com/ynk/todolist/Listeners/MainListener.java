package com.ynk.todolist.Listeners;

public interface MainListener {

    void openPage(String pageCode);

}
