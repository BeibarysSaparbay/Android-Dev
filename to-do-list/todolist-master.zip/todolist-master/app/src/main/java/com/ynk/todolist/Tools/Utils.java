package com.ynk.todolist.Tools;

public class Utils {

    public static final String APP_NAME = "TODOLIST";

    //Login Utils
    public static final String loginControlKey = "isLogin";
    public static final String loginUserNameKey = "userName";
    public static final String loginUserPassword = "userPassword";

    public static final String todoListFragmentTag = "todolist";

}
