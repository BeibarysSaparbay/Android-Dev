# COVID-19 Tracker Android App 
Coronavirus (COVID-19) Tracker App Using REST API & Volley Library

# Screenshots 
<p float="left">
 <img src="https://github.com/arsltech/COVID-19Tracker/blob/master/image1.jpg" width="200" height="400" />
<img src="https://github.com/arsltech/COVID-19Tracker/blob/master/image2.jpg" width="200" height="400" />
<img src="https://github.com/arsltech/COVID-19Tracker/blob/master/image3.jpg" width="200" height="400" />

</p>


